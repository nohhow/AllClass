<div class="container-fluid px-4">
    <div class="d-flex align-items-center justify-content-between small">
        <div class="text-muted">모두의 클래스 | 세상의 모든 교실</div>
        <div>
            <ul>Contact
                <li>- 노진현 : jinhyeon.noh@gmail.com</li>
                <li>- 김호균 : h0kyungim@gmail.com</li>
            </ul>
        </div>
    </div>
</div>