-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- 생성 시간: 21-06-21 09:51
-- 서버 버전: 8.0.24
-- PHP 버전: 7.3.24-(to be removed in future macOS)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `all_class`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `assg_board_class`
--

CREATE TABLE `assg_board_class` (
  `num` int NOT NULL,
  `title` char(40) NOT NULL,
  `content` text NOT NULL,
  `regist_day` char(20) NOT NULL,
  `class_code` char(40) DEFAULT NULL,
  `deadline` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `assg_board_class`
--
ALTER TABLE `assg_board_class`
  ADD PRIMARY KEY (`num`),
  ADD KEY `assg_board_class_ibfk_1` (`class_code`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `assg_board_class`
--
ALTER TABLE `assg_board_class`
  MODIFY `num` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- 덤프된 테이블의 제약사항
--

--
-- 테이블의 제약사항 `assg_board_class`
--
ALTER TABLE `assg_board_class`
  ADD CONSTRAINT `assg_board_class_ibfk_1` FOREIGN KEY (`class_code`) REFERENCES `classes` (`class_code`) ON DELETE CASCADE ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
