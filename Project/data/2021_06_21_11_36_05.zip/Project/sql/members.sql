-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- 생성 시간: 21-06-21 09:52
-- 서버 버전: 8.0.24
-- PHP 버전: 7.3.24-(to be removed in future macOS)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `all_class`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `members`
--

CREATE TABLE `members` (
  `id` char(15) NOT NULL,
  `pass` char(15) NOT NULL,
  `name` char(10) NOT NULL,
  `birth` int DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `email` char(80) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `regist_day` char(20) DEFAULT NULL,
  `active` int NOT NULL DEFAULT '0',
  `hash` char(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- 테이블의 덤프 데이터 `members`
--

INSERT INTO `members` (`id`, `pass`, `name`, `birth`, `gender`, `email`, `regist_day`, `active`, `hash`) VALUES
('1998njh', '1111', '노진수', 19970403, '남', '1998njh@naver.com', '2021-05-21 (21:32)', 1, '3a0772443a0739141292a5429b952fe6'),
('njh1998', '1111', '테스터노진현', 19970403, '남', 'noh_how@naver.com', '2021-06-21 (02:34)', 1, '64223ccf70bbb65a3a4aceac37e21016'),
('test1', '1111', '노진현', 19970303, '남', 'jinhyeon.noh@gmail.com', '2021-06-19 (12:17)', 1, 'd86ea612dec96096c5e0fcc8dd42ab6d'),
('test_creator', 'test1', 'creator', 20210621, '남', 'bosu40@gmail.com', '2021-06-21 (00:09)', 1, 'f0adc8838f4bdedde4ec2cfad0515589'),
('xksrma97', '1111', '노진현', 19970403, '남', 'xksrma97@gmail.com', '2021-05-30 (12:53)', 1, 'c8fbbc86abe8bd6a5eb6a3b4d0411301');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
