-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- 생성 시간: 21-06-21 09:52
-- 서버 버전: 8.0.24
-- PHP 버전: 7.3.24-(to be removed in future macOS)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `all_class`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `classes`
--

CREATE TABLE `classes` (
  `class_name` char(20) NOT NULL,
  `class_info` char(30) NOT NULL,
  `class_code` char(40) NOT NULL,
  `creator` char(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- 테이블의 덤프 데이터 `classes`
--

INSERT INTO `classes` (`class_name`, `class_info`, `class_code`, `creator`) VALUES
('데이터베이스', '충남대 DB', '60b4d1f35a263', '1998njh'),
('정보처리기사 자격증 모임', '정처기 2021 3회차 학습', '60c32598aa82e', 'njh1998'),
('React 스터디', '리액트 + 리액트 네이티브 스터디', '60cd5fa82727c', '1998njh'),
('자료구조', '한남대 자료구조', '60cf471b3d2e3', 'xksrma97'),
('create_test', '클래스 생성 테스트', '60cf5ab05986f', 'test_creator'),
('PHP', '한남대 웹프로그래밍', '60cf7c65651b3', 'njh1998');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
