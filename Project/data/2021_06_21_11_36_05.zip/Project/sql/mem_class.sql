-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- 생성 시간: 21-06-21 09:52
-- 서버 버전: 8.0.24
-- PHP 버전: 7.3.24-(to be removed in future macOS)

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `all_class`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `mem_class`
--

CREATE TABLE `mem_class` (
  `class_code` char(40) DEFAULT NULL,
  `mem_id` char(15) DEFAULT NULL,
  `role` char(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- 테이블의 덤프 데이터 `mem_class`
--

INSERT INTO `mem_class` (`class_code`, `mem_id`, `role`) VALUES
('60b4d1f35a263', '1998njh', 'T'),
('60b4d1f35a263', 'xksrma97', 'S'),
('60cd5fa82727c', '1998njh', 'T'),
('60cf471b3d2e3', 'xksrma97', 'T'),
('60cf5ab05986f', 'test_creator', 'T'),
('60cf5ab05986f', 'xksrma97', 'S'),
('60cf5ab05986f', '1998njh', 'S'),
('60cf471b3d2e3', '1998njh', 'S'),
('60cf7c65651b3', 'njh1998', 'T');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `mem_class`
--
ALTER TABLE `mem_class`
  ADD KEY `mem_class_ibfk_1` (`class_code`),
  ADD KEY `mem_class_ibfk_2` (`mem_id`);

--
-- 덤프된 테이블의 제약사항
--

--
-- 테이블의 제약사항 `mem_class`
--
ALTER TABLE `mem_class`
  ADD CONSTRAINT `mem_class_ibfk_1` FOREIGN KEY (`class_code`) REFERENCES `classes` (`class_code`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `mem_class_ibfk_2` FOREIGN KEY (`mem_id`) REFERENCES `members` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
